#Loading wine data
library(readxl)
wine <- read.csv("G:/practical data science/Assignments/Data unsupervised learning/wine.csv")
mydata <- wine[ ,c(1, 3:8)]
# mydata <- wine[ , -2]

## the first column in mydata has university names
data <- mydata[, -1]
attach(data)
?princomp
pcaobj <- princomp(wine, cor=TRUE, scores = TRUE, covmat = NULL)
str(pcaobj)
summary(pcaobj)
loadings(pcaobj)
biplot(pcaobj)

plot(cumsum(pcaobj$sdev * pcaobj$sdev) * 100 / (sum(pcaobj$sdev * pcaobj$sdev)), type = "b")

pcaobj$scores
pcaobj$scores[, 1:3]

#Top 3 pca scores

final <- cbind(wine [, 1], pcaobj$scores[, 1:3])
view(final)

# Scatter diagram

Final <- as.data.frame(final)
view(Final)

